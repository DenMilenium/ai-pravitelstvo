'use client';

import { useState, useEffect, useCallback } from 'react';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

// Хук для получения новостей
export function useNews(limit = 10, category?: string) {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const url = new URL(`${API_URL}/api/news`);
        url.searchParams.append('limit', limit.toString());
        if (category) url.searchParams.append('category', category);
        
        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch news');
        
        const data = await response.json();
        setNews(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, [limit, category]);

  return { news, loading, error };
}

// Хук для одной новости
export function useNewsItem(id: number) {
  const [newsItem, setNewsItem] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!id) return;
    
    const fetchNewsItem = async () => {
      try {
        const response = await fetch(`${API_URL}/api/news/${id}`);
        if (!response.ok) throw new Error('News not found');
        
        const data = await response.json();
        setNewsItem(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchNewsItem();
  }, [id]);

  return { newsItem, loading, error };
}

// Хук для документов
export function useDocuments(limit = 20, category?: string) {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchDocuments = async () => {
      try {
        const url = new URL(`${API_URL}/api/documents`);
        url.searchParams.append('limit', limit.toString());
        if (category) url.searchParams.append('category', category);
        
        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch documents');
        
        const data = await response.json();
        setDocuments(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchDocuments();
  }, [limit, category]);

  return { documents, loading, error };
}

// Хук для статистики
export function useStatistics() {
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch(`${API_URL}/api/statistics/summary`);
        if (!response.ok) throw new Error('Failed to fetch statistics');
        
        const data = await response.json();
        setStatistics(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  return { statistics, loading, error };
}

// Хук для отправки обращения
export function useAppeal() {
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  const submitAppeal = useCallback(async (appealData: {
    full_name: string;
    email: string;
    phone?: string;
    subject: string;
    message: string;
  }) => {
    setSubmitting(true);
    setError(null);
    setSuccess(false);

    try {
      const response = await fetch(`${API_URL}/api/appeals`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(appealData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to submit appeal');
      }

      setSuccess(true);
      return await response.json();
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setSubmitting(false);
    }
  }, []);

  return { submitAppeal, submitting, success, error };
}

// Хук для проверки API
export function useHealthCheck() {
  const [status, setStatus] = useState<'online' | 'offline' | 'checking'>('checking');

  useEffect(() => {
    const checkHealth = async () => {
      try {
        const response = await fetch(`${API_URL}/api/health`, {
          method: 'GET',
          // Short timeout for health check
          signal: AbortSignal.timeout(5000)
        });
        
        if (response.ok) {
          setStatus('online');
        } else {
          setStatus('offline');
        }
      } catch {
        setStatus('offline');
      }
    };

    checkHealth();
    const interval = setInterval(checkHealth, 30000); // Check every 30s
    
    return () => clearInterval(interval);
  }, []);

  return status;
}
